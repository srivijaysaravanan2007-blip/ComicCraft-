# ComicCraft — AI Comic Story Creator

A complete FastAPI + Jinja2 web application based on the supplied ComicCraft documentation. It accepts a story prompt, character, setting, tone, art style and panel count; generates a structured comic outline and story with Gemini; generates panel artwork through Hugging Face Inference Providers; renders a preview; and exports a PDF.

The supplied document describes Gemini Flash/Pro and Stable Diffusion. Those exact model names are historical, so this implementation uses the current `google-genai` SDK and a configurable Gemini model, plus Hugging Face Inference Providers for hosted text-to-image generation. Hugging Face supports text-to-image through `InferenceClient` and automatic provider selection.

## Project structure

```text
ComicCraft_COMPLETE/
├── app/
│   ├── main.py
│   ├── routes.py
│   ├── config.py
│   ├── schemas.py
│   ├── gemini_flash.py
│   ├── gemini_pro.py
│   ├── image_generator.py
│   ├── layout_builder.py
│   └── exporters.py
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   ├── panels/
│   └── exports/
├── tests/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. Prerequisites

- Windows 10/11, macOS, or Linux
- Python 3.11 or newer
- VS Code
- A Gemini API key
- A Hugging Face token with permission to use Inference Providers if you want real generated panel artwork

## 2. VS Code setup (Windows)

Open the `ComicCraft_COMPLETE` folder in VS Code.

Open **Terminal → New Terminal** and run:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt:

```bat
.venv\Scripts\activate.bat
pip install -r requirements.txt
```

## 3. Configure API keys

Copy `.env.example` to `.env`.

Put your real Gemini key in:

```env
GEMINI_API_KEY=...
```

For real image generation, put your Hugging Face token in:

```env
HF_TOKEN=hf_...
```

The application intentionally never hard-codes keys into source files.

## 4. Start the app

```powershell
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000 — website
- http://127.0.0.1:8000/docs — interactive API documentation
- http://127.0.0.1:8000/health — configuration/health check

## 5. First test

Open `/health`. You should see `status: ok`.

Then create a comic using:

- Story: `A brave fox discovers a hidden library beneath an enchanted forest.`
- Character: `Luna`
- Setting: `Enchanted forest`
- Tone: `Adventure`
- Art style: `Comic book`
- Panels: `5`

Click **Create My Comic**.

## 6. Image generation behavior

If `HF_TOKEN` is configured, the app calls Hugging Face text-to-image inference.

If `HF_TOKEN` is missing or the image provider fails and `ALLOW_DEMO_IMAGES=true`, the app creates a local labeled placeholder so you can test the complete FastAPI → preview → PDF workflow without waiting for an image service.

Set:

```env
ALLOW_DEMO_IMAGES=false
```

when you want image failures to be surfaced instead of falling back to placeholders.

## 7. API test

POST `/generate-comic/json` with:

```json
{
  "story_prompt": "A brave fox discovers a hidden library beneath an enchanted forest.",
  "character_name": "Luna",
  "setting": "Enchanted forest",
  "tone": "Adventure",
  "art_style": "Comic book",
  "panel_count": 5
}
```

POST `/test-image` with:

```json
{
  "prompt": "Comic-book illustration of a brave orange fox standing at the entrance of a glowing hidden library, dramatic moonlight, dynamic composition, no text"
}
```

## 8. Troubleshooting

### `GEMINI_API_KEY is not configured`
Check that `.env` exists in the project root, contains the key, and restart Uvicorn after editing it.

### Gemini returns 429/503
This is an upstream model/service availability or quota issue, not a FastAPI routing problem. Wait and retry, or change `GEMINI_MODEL` to another model available to your API project.

### Image generation fails
Verify `HF_TOKEN`, the token's Inference Providers permission, and the selected `IMAGE_MODEL`. The app can fall back to demo images if `ALLOW_DEMO_IMAGES=true`.

### PDF contains odd characters
The PDF exporter uses FPDF's built-in Helvetica for maximum portability. Keep generated dialogue mostly ASCII, or add a Unicode TTF font to `exporters.py` if your project requires full Unicode PDF output.

## 9. GitHub

After testing locally:

```powershell
git init
git add .
git commit -m "Build ComicCraft AI comic creator"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ComicCraft.git
git push -u origin main
```

Never commit `.env` or API keys.


## Important: Gemini 503 fallback
If Gemini temporarily returns HTTP 503/UNAVAILABLE, ComicCraft now automatically switches to a deterministic local story/outline generator when `OFFLINE_FALLBACK=true`. This keeps the demo working instead of returning a 400 error. When Gemini is available, the app still uses the configured Gemini model.

For real AI images, set `HF_TOKEN`. If it is missing or image generation fails, `ALLOW_DEMO_IMAGES=true` creates clearly labeled local placeholder panel images so the full comic/PDF flow can still be demonstrated.

### Windows quick start
1. Open this folder in VS Code.
2. In PowerShell run `env\Scripts\python.exe -m pip install -r requirements.txt`.
3. Copy `.env.example` to `.env`.
4. Put your Gemini API key in `GEMINI_API_KEY` if you want Gemini generation. Keep `OFFLINE_FALLBACK=true`.
5. Optionally put your Hugging Face token in `HF_TOKEN` for real panel images.
6. Run `env\Scripts\python.exe -m uvicorn app.main:app --reload`.
7. Open `http://127.0.0.1:8000`.

If Gemini is currently unavailable, you can still click **Create My Comic** and complete the end-to-end demo using the local fallback.
