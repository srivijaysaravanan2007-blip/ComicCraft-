from pathlib import Path
from datetime import datetime
from fpdf import FPDF
from .config import BASE_DIR

EXPORT_DIR = BASE_DIR / "static" / "exports"
EXPORT_DIR.mkdir(parents=True, exist_ok=True)

def _pdf_text(value: str) -> str:
    return str(value).encode("latin-1", "replace").decode("latin-1")

def save_pdf(layout) -> str:
    filename = f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
    output = EXPORT_DIR / filename
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=12)
    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(180, 10,  _pdf_text(f"Panel {panel['panel_number']}: {panel['title']}"))
        image_file = BASE_DIR / panel["image_path"].lstrip("/").replace("/", "/")
        if image_file.exists():
            pdf.image(str(image_file), x=15, y=35, w=180, h=120)
        pdf.set_xy(15, 160)
        pdf.set_x(15)
        pdf.set_font("Helvetica", "I", 11)
        pdf.multi_cell(180, 6, _pdf_text(panel.get("scene_description", "")))
        pdf.ln(3)
        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(180, 6, "Caption")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(180, 6, _pdf_text(panel.get("caption", "")))
        pdf.ln(2)
        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(180, 6, "Narration")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(180, 6, _pdf_text(panel.get("narration", "")))
        if panel.get("dialogue"):
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(180, 6, "Dialogue")
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(180, 6, _pdf_text("\n".join(panel["dialogue"])))
    pdf.output(str(output))
    return f"/static/exports/{filename}"
