from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .config import settings, BASE_DIR
from .routes import router

app = FastAPI(title=settings.app_name, version="1.0.0", description="AI comic story creator")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.include_router(router)

@app.get("/health")
def health():
    return {"status": "ok", "gemini_configured": bool(settings.gemini_api_key), "image_api_configured": bool(settings.hf_token), "demo_images": settings.allow_demo_images}
