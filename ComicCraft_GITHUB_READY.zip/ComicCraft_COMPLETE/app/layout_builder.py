def build_comic_layout(stories, image_paths):
    layout = []
    for story, image in zip(stories, image_paths):
        item = story.model_dump() if hasattr(story, "model_dump") else dict(story)
        item["image_path"] = image
        layout.append(item)
    return layout
