from pydantic import BaseModel, Field, field_validator

class ComicRequest(BaseModel):
    story_prompt: str = Field(..., min_length=5, max_length=2000)
    character_name: str = Field(..., min_length=1, max_length=80)
    setting: str = Field(..., min_length=1, max_length=120)
    tone: str = Field(..., min_length=1, max_length=50)
    art_style: str = Field(..., min_length=1, max_length=80)
    panel_count: int = Field(default=5, ge=1, le=8)

    @field_validator("story_prompt", "character_name", "setting", "tone", "art_style")
    @classmethod
    def strip_values(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("This field cannot be empty")
        return value

class ImageTestRequest(BaseModel):
    prompt: str = Field(..., min_length=5, max_length=1500)

class PanelOutline(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str

class PanelStory(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str
    caption: str
    narration: str
    dialogue: list[str] = []

class ComicResult(BaseModel):
    panels: list[PanelStory]
    pdf_url: str
