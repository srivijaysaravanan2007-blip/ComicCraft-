import json
import re
import time
from .config import settings
from .schemas import ComicRequest, PanelOutline

class GeminiError(RuntimeError):
    pass

def _client():
    if not settings.gemini_api_key:
        raise GeminiError("GEMINI_API_KEY is not configured.")
    try:
        from google import genai
    except ImportError as exc:
        raise GeminiError("The google-genai package is missing. Run: pip install -r requirements.txt") from exc
    return genai.Client(api_key=settings.gemini_api_key), genai

def _extract_json(text: str):
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}|\[.*\]", text, flags=re.S)
        if not match:
            raise GeminiError("Gemini returned an invalid JSON response.")
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError as exc:
            raise GeminiError("Gemini returned malformed JSON.") from exc

def _local_outline(request: ComicRequest) -> list[PanelOutline]:
    """Deterministic offline outline used when Gemini is unavailable."""
    beats = [
        ("The Beginning", "introduces the main character and the unusual situation"),
        ("A Strange Discovery", "reveals an important clue and raises the stakes"),
        ("Trouble Arrives", "creates a funny or dramatic obstacle"),
        ("The Big Idea", "shows the character using a clever solution"),
        ("A New Adventure", "ends with a satisfying result and a hint of what comes next"),
        ("Unexpected Twist", "adds a playful final surprise"),
        ("The Challenge", "shows the character facing one last small obstacle"),
        ("The Finale", "wraps up the adventure with a memorable final image"),
    ]
    panels = []
    for i in range(request.panel_count):
        title, beat = beats[i % len(beats)]
        scene = (
            f"{request.character_name} is in the {request.setting}. The panel {beat} "
            f"while following this story idea: {request.story_prompt}"
        )
        prompt = (
            f"{request.art_style} comic book illustration, {request.setting}; "
            f"main character {request.character_name}, consistent appearance across panels; "
            f"{scene}; expressive action, clear composition, cinematic lighting, dynamic camera angle; "
            "clean line art, detailed background, no text, no speech bubbles."
        )
        panels.append(PanelOutline(
            panel_number=i + 1,
            title=title,
            scene_description=scene,
            image_prompt=prompt,
        ))
    return panels

def _temporary(exc: Exception) -> bool:
    msg = str(exc).upper()
    return any(x in msg for x in ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "INTERNAL", "DEADLINE_EXCEEDED", "TIMEOUT", "OVERLOADED"))

def _models():
    configured = str(getattr(settings, "gemini_model", "") or "").strip()
    names = [configured, "gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-flash-latest"]
    return list(dict.fromkeys(x for x in names if x))

def generate_outline(request: ComicRequest) -> list[PanelOutline]:
    if not settings.gemini_api_key:
        if settings.offline_fallback:
            print("COMICCRAFT: Gemini key missing; using local outline fallback.")
            return _local_outline(request)
        raise GeminiError("GEMINI_API_KEY is not configured. Add it to .env and restart the server.")

    try:
        client, genai = _client()
    except GeminiError:
        if settings.offline_fallback:
            return _local_outline(request)
        raise

    prompt = f"""Create a coherent {request.panel_count}-panel comic outline.\nUser story: {request.story_prompt}\nMain character: {request.character_name}\nSetting: {request.setting}\nTone: {request.tone}\nArt style: {request.art_style}\nReturn ONLY JSON: {{\"panels\":[{{\"panel_number\":1,\"title\":\"...\",\"scene_description\":\"...\",\"image_prompt\":\"...\"}}]}}\nExactly {request.panel_count} panels. Keep the character visually consistent. Image prompts must describe composition, appearance, action, lighting, camera angle and style, with no text or speech bubbles."""
    last_error = None
    for model in _models():
        for attempt in range(2):
            try:
                response = client.models.generate_content(
                    model=model,
                    contents=prompt,
                    config=genai.types.GenerateContentConfig(temperature=0.9, max_output_tokens=5000),
                )
                data = _extract_json(getattr(response, "text", ""))
                raw = data.get("panels") if isinstance(data, dict) else data
                panels = [PanelOutline.model_validate(x) for x in raw]
                if len(panels) != request.panel_count:
                    raise GeminiError(f"Gemini returned {len(panels)} panels instead of {request.panel_count}.")
                return panels
            except GeminiError:
                raise
            except Exception as exc:
                last_error = exc
                if _temporary(exc) and attempt == 0:
                    time.sleep(2)
                    continue
                break
    if settings.offline_fallback:
        print(f"COMICCRAFT: Gemini unavailable ({last_error}); using local outline fallback.")
        return _local_outline(request)
    raise GeminiError(f"Outline generation failed: {last_error}")
