from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from huggingface_hub import InferenceClient
from .config import settings, BASE_DIR

class ImageGenerationError(RuntimeError):
    pass

PANELS_DIR = BASE_DIR / "static" / "panels"
PANELS_DIR.mkdir(parents=True, exist_ok=True)

def _font(size: int):
    candidates = [
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()

def _demo_image(prompt: str, path: Path, panel_number: int):
    image = Image.new("RGB", (768, 1024), "#f4eadb")
    draw = ImageDraw.Draw(image)
    title_font = _font(42)
    body_font = _font(22)
    draw.rectangle((28, 28, 740, 996), outline="#1b1b1b", width=8)
    draw.text((60, 70), f"COMICCRAFT • PANEL {panel_number}", font=title_font, fill="#1b1b1b")
    draw.rounded_rectangle((70, 190, 698, 700), radius=30, fill="#d7e9f7", outline="#1b1b1b", width=5)
    draw.ellipse((270, 285, 500, 515), fill="#f0c6a4", outline="#1b1b1b", width=5)
    draw.arc((315, 350, 455, 460), 20, 160, fill="#1b1b1b", width=5)
    draw.text((70, 750), "Demo image mode", font=title_font, fill="#1b1b1b")
    # Wrap prompt for a useful local placeholder when no image API is configured.
    words = prompt[:500].split()
    lines, line = [], ""
    for word in words:
        test = f"{line} {word}".strip()
        if draw.textlength(test, font=body_font) > 620:
            lines.append(line); line = word
        else:
            line = test
    if line: lines.append(line)
    draw.multiline_text((70, 820), "\n".join(lines[:6]), font=body_font, fill="#222", spacing=8)
    image.save(path)

def generate_image(prompt: str, panel_number: int) -> str:
    path = PANELS_DIR / f"panel_{panel_number}.png"
    if not settings.hf_token:
        if settings.allow_demo_images:
            _demo_image(prompt, path, panel_number)
            return f"/static/panels/{path.name}"
        raise ImageGenerationError("HF_TOKEN is not configured. Add it to .env or enable ALLOW_DEMO_IMAGES=true.")
    try:
        client = InferenceClient(provider=settings.image_provider, api_key=settings.hf_token)
        image = client.text_to_image(
            prompt=prompt,
            model=settings.image_model,
        )
        image.save(path)
        return f"/static/panels/{path.name}"
    except Exception as exc:
        if settings.allow_demo_images:
            _demo_image(prompt, path, panel_number)
            return f"/static/panels/{path.name}"
        raise ImageGenerationError(f"Image generation failed for panel {panel_number}: {exc}") from exc
