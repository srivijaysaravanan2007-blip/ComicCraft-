from fastapi import APIRouter, Form, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from .schemas import ComicRequest, ImageTestRequest
from .gemini_flash import generate_outline, GeminiError
from .gemini_pro import generate_story
from .image_generator import generate_image, ImageGenerationError
from .layout_builder import build_comic_layout
from .exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory="templates")

def create_comic(data: ComicRequest):
    outline = generate_outline(data)
    stories = generate_story(data, outline)
    images = [generate_image(panel.image_prompt, panel.panel_number) for panel in stories]
    layout = build_comic_layout(stories, images)
    pdf_url = save_pdf(layout)
    return layout, pdf_url

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})

@router.post("/generate", response_class=HTMLResponse)
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
    panel_count: int = Form(5),
):
    try:
        data = ComicRequest(story_prompt=story_prompt, character_name=character_name, setting=setting, tone=tone, art_style=art_style, panel_count=panel_count)
        layout, pdf_url = create_comic(data)
        return templates.TemplateResponse(request=request, name="comic_preview.html", context={"layout": layout, "pdf_url": pdf_url})
    except (GeminiError, ImageGenerationError, ValueError) as exc:
        return templates.TemplateResponse(request=request, name="index.html", context={"error": str(exc)}, status_code=400)
    except Exception as exc:
        return templates.TemplateResponse(request=request, name="index.html", context={"error": f"Unexpected generation error: {exc}"}, status_code=500)

@router.post("/generate-comic/json")
async def generate_json(data: ComicRequest):
    try:
        layout, pdf_url = create_comic(data)
        return JSONResponse({"success": True, "panels": layout, "pdf_url": pdf_url})
    except (GeminiError, ImageGenerationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Unexpected generation error: {exc}") from exc

@router.post("/test-image")
async def test_image(data: ImageTestRequest):
    try:
        return {"success": True, "image_url": generate_image(data.prompt, 0)}
    except ImageGenerationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request):
    return templates.TemplateResponse(request=request, name="export_success.html", context={})
