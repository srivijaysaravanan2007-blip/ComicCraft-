from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    gemini_api_key: str = ""
    gemini_model: str = "gemini-3.8-flash"
    offline_fallback: bool = True
    hf_token: str = ""
    image_model: str = "black-forest-labs/FLUX.1-schnell"
    image_provider: str = "auto"
    allow_demo_images: bool = True
    image_width: int = 768
    image_height: int = 1024
    max_panels: int = 8
    default_panels: int = 5
    model_timeout_seconds: int = 90
    model_retries: int = 2

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

@lru_cache
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
