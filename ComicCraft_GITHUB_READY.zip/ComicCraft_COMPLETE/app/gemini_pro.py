import json
import re
from .config import settings
from .schemas import ComicRequest, PanelOutline, PanelStory
from .gemini_flash import GeminiError

def _client():
    if not settings.gemini_api_key:
        raise GeminiError("GEMINI_API_KEY is not configured.")
    try:
        from google import genai
    except ImportError as exc:
        raise GeminiError("The google-genai package is missing. Run: pip install -r requirements.txt") from exc
    return genai.Client(api_key=settings.gemini_api_key), genai

def _extract_json(text: str):
    text = re.sub(r"^```(?:json)?\s*", "", (text or "").strip(), flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, flags=re.S)
        if not m:
            raise GeminiError("Gemini returned invalid story JSON.")
        return json.loads(m.group(0))

def _local_story(request: ComicRequest, outline: list[PanelOutline]) -> list[PanelStory]:
    result = []
    for p in outline:
        dialogue = [f"{request.character_name}: What an adventure!"]
        result.append(PanelStory(
            panel_number=p.panel_number,
            title=p.title,
            scene_description=p.scene_description,
            image_prompt=p.image_prompt,
            caption=p.title,
            narration=p.scene_description,
            dialogue=dialogue,
        ))
    return result

def generate_story(request: ComicRequest, outline: list[PanelOutline]) -> list[PanelStory]:
    if not settings.gemini_api_key:
        if settings.offline_fallback:
            print("COMICCRAFT: Gemini key missing; using local story fallback.")
            return _local_story(request, outline)
        raise GeminiError("GEMINI_API_KEY is not configured. Add it to .env and restart the server.")
    try:
        client, genai = _client()
        compact = [p.model_dump() for p in outline]
        prompt = f"""Expand this comic outline into polished panel-by-panel comic copy. Character: {request.character_name}; Setting: {request.setting}; Tone: {request.tone}; Art style: {request.art_style}. Outline: {json.dumps(compact, ensure_ascii=False)} Return ONLY JSON: {{\"panels\":[{{\"panel_number\":1,\"title\":\"...\",\"scene_description\":\"...\",\"image_prompt\":\"...\",\"caption\":\"...\",\"narration\":\"...\",\"dialogue\":[\"CHARACTER: line\"]}}]}} Preserve the number of panels and keep each panel concise."""
        response = client.models.generate_content(model=settings.gemini_model, contents=prompt, config=genai.types.GenerateContentConfig(temperature=0.85, max_output_tokens=7000))
        data = _extract_json(getattr(response, "text", ""))
        panels = [PanelStory.model_validate(p) for p in data.get("panels", [])]
        if len(panels) != len(outline):
            raise GeminiError("Story generation returned the wrong number of panels.")
        return panels
    except Exception as exc:
        if settings.offline_fallback:
            print(f"COMICCRAFT: Story generation unavailable ({exc}); using local story fallback.")
            return _local_story(request, outline)
        if isinstance(exc, GeminiError):
            raise
        raise GeminiError(f"Story generation failed: {exc}") from exc
