// Reserved for progressive enhancements. The core app works without JavaScript.
