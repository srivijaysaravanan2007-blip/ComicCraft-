@echo off
if not exist .venv\Scripts\python.exe (
  py -3.11 -m venv .venv
  .venv\Scripts\python.exe -m pip install --upgrade pip
  .venv\Scripts\pip.exe install -r requirements.txt
)
call .venv\Scripts\activate.bat
uvicorn app.main:app --reload
